﻿using System.Windows;

namespace ZooMap
{
    public partial class App : Application
    {
    }
}