﻿using System.Windows;

namespace ZooMap
{
    public partial class AdminPanelWindow : Window
    {
        public AdminPanelWindow()
        {
            InitializeComponent();
        }
    }
}